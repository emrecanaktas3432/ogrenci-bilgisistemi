"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  BookOpen,
  GraduationCap,
  User,
  Calendar,
  Award,
  Calculator,
  Cloud,
  MessageCircle,
  Sun,
  CloudRain,
  CloudSnow,
} from "lucide-react"

// Components
import { LoginForm } from "@/components/login-form"
import { Header } from "@/components/header"
import { GradeManager } from "@/components/grade-manager"
import { ScheduleEditor } from "@/components/schedule-editor"

// Auth imports
import { getCurrentUser, type User as UserType } from "@/lib/auth"

// JSON Database imports
import {
  getStudent,
  updateStudent,
  getStudentCourses,
  getMessages,
  sendMessage,
  getAnnouncements,
  getWeather,
  changePassword,
} from "@/lib/simple-database"

import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Send } from "lucide-react"

export default function StudentInfoSystem() {
  const [currentUser, setCurrentUser] = useState<UserType | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("dashboard")
  const [newMessage, setNewMessage] = useState("")
  const [selectedChat, setSelectedChat] = useState(null)
  const [dataLoading, setDataLoading] = useState(false)

  // Database state
  const [student, setStudent] = useState(null)
  const [courses, setCourses] = useState([])
  const [messages, setMessages] = useState([])
  const [announcements, setAnnouncements] = useState([])
  const [weather, setWeather] = useState(null)

  // Check authentication on mount
  useEffect(() => {
    const user = getCurrentUser()
    setCurrentUser(user)
    setIsLoading(false)
  }, [])

  // Load data when user is authenticated
  useEffect(() => {
    if (currentUser && currentUser.role === "student") {
      loadData()
    }
  }, [currentUser])

  const loadData = async () => {
    setDataLoading(true)
    try {
      console.log("📁 JSON veritabanından veri yükleniyor...")

      // Load student data
      const studentData = getStudent(currentUser?.student_id || "2021000001")
      console.log("✅ Öğrenci verisi yüklendi:", studentData)

      if (studentData) {
        setStudent(studentData)

        // Load student's courses
        const coursesData = getStudentCourses(studentData.student_id)
        console.log("✅ Ders verileri yüklendi:", coursesData)
        setCourses(coursesData)

        // Load messages
        const messagesData = getMessages(studentData.id)
        console.log("✅ Mesaj verileri yüklendi:", messagesData)
        setMessages(messagesData)
      }

      // Load announcements
      const announcementsData = getAnnouncements()
      setAnnouncements(announcementsData)

      // Load weather
      const weatherData = getWeather()
      setWeather(weatherData)

      console.log("🎉 Tüm veriler JSON dosyasından başarıyla yüklendi!")
    } catch (error) {
      console.error("❌ Veri yükleme hatası:", error)
    } finally {
      setDataLoading(false)
    }
  }

  const handleLoginSuccess = () => {
    const user = getCurrentUser()
    setCurrentUser(user)
  }

  // Rest of your existing component code...
  const [editableProfile, setEditableProfile] = useState({
    email: "",
    phone: "",
  })

  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  })

  const [gradeCalculator, setGradeCalculator] = useState({
    midterm: "",
    final: "",
    midtermWeight: 40,
    finalWeight: 60,
    homework: "",
    homeworkWeight: 0,
    quiz: "",
    quizWeight: 0,
  })

  const [calculatedGrade, setCalculatedGrade] = useState(null)
  const [letterGrade, setLetterGrade] = useState("")

  // Update profile when student data loads
  useEffect(() => {
    if (student) {
      setEditableProfile({
        email: student.email || "",
        phone: student.phone || "",
      })
    }
  }, [student])

  const calculateGrade = () => {
    const midterm = Number.parseFloat(gradeCalculator.midterm) || 0
    const final = Number.parseFloat(gradeCalculator.final) || 0
    const homework = Number.parseFloat(gradeCalculator.homework) || 0
    const quiz = Number.parseFloat(gradeCalculator.quiz) || 0

    const totalWeight =
      gradeCalculator.midtermWeight +
      gradeCalculator.finalWeight +
      gradeCalculator.homeworkWeight +
      gradeCalculator.quizWeight

    if (totalWeight !== 100) {
      alert("Ağırlık yüzdeleri toplamı 100 olmalıdır!")
      return
    }

    const grade =
      (midterm * gradeCalculator.midtermWeight) / 100 +
      (final * gradeCalculator.finalWeight) / 100 +
      (homework * gradeCalculator.homeworkWeight) / 100 +
      (quiz * gradeCalculator.quizWeight) / 100

    setCalculatedGrade(grade.toFixed(2))

    // Harf notu hesaplama
    if (grade >= 90) setLetterGrade("AA")
    else if (grade >= 85) setLetterGrade("BA")
    else if (grade >= 80) setLetterGrade("BB")
    else if (grade >= 75) setLetterGrade("CB")
    else if (grade >= 70) setLetterGrade("CC")
    else if (grade >= 65) setLetterGrade("DC")
    else if (grade >= 60) setLetterGrade("DD")
    else if (grade >= 50) setLetterGrade("FD")
    else setLetterGrade("FF")
  }

  const getWeatherIcon = (condition) => {
    switch (condition) {
      case "sunny":
        return <Sun className="h-8 w-8 text-yellow-500" />
      case "rainy":
        return <CloudRain className="h-8 w-8 text-blue-500" />
      case "snowy":
        return <CloudSnow className="h-8 w-8 text-gray-400" />
      default:
        return <Cloud className="h-8 w-8 text-gray-500" />
    }
  }

  const handleSendMessage = async () => {
    if (newMessage.trim() && selectedChat && student) {
      try {
        // JSON veritabanına mesaj gönder
        const receiverId = selectedChat.sender_id || "demo-receiver"
        const result = sendMessage(student.id, receiverId, newMessage, student.name)

        if (result) {
          setNewMessage("")
          // Mesajları yeniden yükle
          const messagesData = getMessages(student.id)
          setMessages(messagesData)
          alert("✅ Mesaj JSON veritabanına kaydedildi!")
        } else {
          alert("❌ Mesaj gönderilemedi!")
        }
      } catch (error) {
        console.error("Error sending message:", error)
        alert("❌ Mesaj gönderilirken hata oluştu!")
      }
    } else {
      alert("⚠️ Lütfen bir mesaj yazın ve sohbet seçin!")
    }
  }

  const handleUpdateProfile = async () => {
    if (student) {
      try {
        const updatedStudent = updateStudent(student.student_id, {
          email: editableProfile.email,
          phone: editableProfile.phone,
        })

        if (updatedStudent) {
          alert("✅ Profil JSON veritabanında güncellendi!")
          setStudent(updatedStudent)
        } else {
          alert("❌ Profil güncellenirken hata oluştu!")
        }
      } catch (error) {
        console.error("Error updating profile:", error)
        alert("❌ Profil güncellenirken hata oluştu!")
      }
    }
  }

  // Şifre değiştirme fonksiyonu
  const handleChangePassword = async () => {
    if (!passwordData.currentPassword || !passwordData.newPassword || !passwordData.confirmPassword) {
      alert("⚠️ Tüm alanları doldurun!")
      return
    }

    if (passwordData.newPassword !== passwordData.confirmPassword) {
      alert("⚠️ Yeni şifreler eşleşmiyor!")
      return
    }

    if (passwordData.newPassword.length < 6) {
      alert("⚠️ Yeni şifre en az 6 karakter olmalıdır!")
      return
    }

    try {
      const result = changePassword(currentUser.id, passwordData.currentPassword, passwordData.newPassword)
      if (result.success) {
        alert("✅ " + result.message)
        setPasswordData({
          currentPassword: "",
          newPassword: "",
          confirmPassword: "",
        })
      } else {
        alert("❌ " + result.message)
      }
    } catch (error) {
      console.error("Error changing password:", error)
      alert("❌ Şifre değiştirilirken hata oluştu!")
    }
  }

  // Show loading screen while checking authentication
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">📁 JSON Veritabanı yükleniyor...</p>
        </div>
      </div>
    )
  }

  // Show login form if not authenticated
  if (!currentUser) {
    return <LoginForm onLoginSuccess={handleLoginSuccess} />
  }

  // Show loading screen while loading data
  if (dataLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">📊 JSON dosyasından veriler yükleniyor...</p>
        </div>
      </div>
    )
  }

  // Show error if student data couldn't be loaded (for student users)
  if (currentUser.role === "student" && !student) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600">❌ JSON veritabanından öğrenci bilgileri yüklenemedi!</p>
          <Button onClick={loadData} className="mt-4">
            🔄 Tekrar Dene
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <Header user={currentUser} unreadCount={messages.filter((m) => !m.is_read).length} />

          {/* JSON Veritabanı Durumu */}
          <div className="mt-2 p-2 bg-green-50 border border-green-200 rounded-lg">
            <p className="text-sm text-green-700">
              📁 <strong>JSON Veritabanı Aktif</strong> - Veriler yerel dosyadan yükleniyor
            </p>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-7">
            <TabsTrigger value="dashboard" className="flex items-center gap-2">
              <GraduationCap className="h-4 w-4" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="courses" className="flex items-center gap-2">
              <BookOpen className="h-4 w-4" />
              Derslerim
            </TabsTrigger>
            <TabsTrigger value="grades" className="flex items-center gap-2">
              <Award className="h-4 w-4" />
              Notlarım
            </TabsTrigger>
            <TabsTrigger value="calculator" className="flex items-center gap-2">
              <Calculator className="h-4 w-4" />
              Not Hesapla
            </TabsTrigger>
            <TabsTrigger value="messages" className="flex items-center gap-2 relative">
              <MessageCircle className="h-4 w-4" />
              Mesajlar
              {messages.filter((m) => !m.is_read).length > 0 && (
                <Badge className="ml-1 h-4 w-4 rounded-full p-0 flex items-center justify-center text-xs">
                  {messages.filter((m) => !m.is_read).length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="profile" className="flex items-center gap-2">
              <User className="h-4 w-4" />
              Profil
            </TabsTrigger>
            <TabsTrigger value="schedule" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Ders Programı
            </TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Genel Not Ortalaması</CardTitle>
                  <Award className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{student?.gpa || "0.00"}</div>
                  <p className="text-xs text-muted-foreground">4.00 üzerinden</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Aktif Dersler</CardTitle>
                  <BookOpen className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{courses.filter((c) => c.status === "enrolled").length}</div>
                  <p className="text-xs text-muted-foreground">Bu dönem</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Toplam Kredi</CardTitle>
                  <GraduationCap className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {courses.reduce((total, course) => total + (course.courses?.credits || 0), 0)}
                  </div>
                  <p className="text-xs text-muted-foreground">Bu dönem</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Devam Durumu</CardTitle>
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">%92</div>
                  <p className="text-xs text-muted-foreground">Genel devam</p>
                </CardContent>
              </Card>

              {/* Hava Durumu Kartı */}
              {weather && (
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Hava Durumu</CardTitle>
                    {getWeatherIcon(weather.condition)}
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{weather.temperature}°C</div>
                    <p className="text-xs text-muted-foreground">{weather.description}</p>
                  </CardContent>
                </Card>
              )}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Son Duyurular</CardTitle>
                  <CardDescription>📁 JSON dosyasından yüklenen duyurular</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {announcements.map((announcement) => (
                    <div key={announcement.id} className="flex items-start space-x-4">
                      <Badge variant="outline">{announcement.type}</Badge>
                      <div className="flex-1">
                        <p className="text-sm font-medium">{announcement.title}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(announcement.created_at).toLocaleDateString("tr-TR")}
                        </p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Akademik İlerleme</CardTitle>
                  <CardDescription>Mezuniyet durumunuz</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Tamamlanan Krediler</span>
                      <span>120/240</span>
                    </div>
                    <Progress value={50} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Zorunlu Dersler</span>
                      <span>85%</span>
                    </div>
                    <Progress value={85} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Seçmeli Dersler</span>
                      <span>60%</span>
                    </div>
                    <Progress value={60} className="h-2" />
                  </div>
                </CardContent>
              </Card>

              {/* Detaylı Hava Durumu Kartı */}
              {weather && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      {getWeatherIcon(weather.condition)}
                      Hava Durumu - {weather.city}
                    </CardTitle>
                    <CardDescription>📁 JSON dosyasından hava durumu</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="text-center">
                      <div className="text-4xl font-bold text-blue-600 mb-2">{weather.temperature}°C</div>
                      <p className="text-lg text-gray-600">{weather.description}</p>
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="flex justify-between">
                        <span>Nem:</span>
                        <span>{weather.humidity}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Rüzgar:</span>
                        <span>{weather.wind_speed} km/h</span>
                      </div>
                    </div>
                    <div className="text-xs text-gray-500 text-center">
                      Son güncelleme: {new Date(weather.updated_at).toLocaleString("tr-TR")}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          {/* Courses Tab */}
          <TabsContent value="courses" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Ders Listesi</CardTitle>
                <CardDescription>📁 JSON dosyasından yüklenen dersler ve notlar</CardDescription>
              </CardHeader>
              <CardContent>
                <GradeManager courses={courses} student={student} onGradeUpdate={loadData} />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Grades Tab */}
          <TabsContent value="grades" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Not Durumu</CardTitle>
                <CardDescription>📁 JSON veritabanından ders notları</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <div className="p-4 bg-blue-50 rounded-lg">
                      <h3 className="font-medium text-blue-900">Genel Not Ortalaması</h3>
                      <p className="text-2xl font-bold text-blue-600">{student?.gpa || "0.00"}</p>
                    </div>
                    <div className="p-4 bg-green-50 rounded-lg">
                      <h3 className="font-medium text-green-900">Başarı Durumu</h3>
                      <p className="text-lg font-semibold text-green-600">
                        {(student?.gpa || 0) >= 2.0 ? "Başarılı" : "Başarısız"}
                      </p>
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse border border-gray-200">
                      <thead>
                        <tr className="bg-gray-50">
                          <th className="border border-gray-200 p-3 text-left">Ders Kodu</th>
                          <th className="border border-gray-200 p-3 text-left">Ders Adı</th>
                          <th className="border border-gray-200 p-3 text-center">Kredi</th>
                          <th className="border border-gray-200 p-3 text-center">Harf Notu</th>
                          <th className="border border-gray-200 p-3 text-center">Puan</th>
                        </tr>
                      </thead>
                      <tbody>
                        {courses
                          .filter((enrollment) => enrollment.grade)
                          .map((enrollment) => (
                            <tr key={enrollment.id}>
                              <td className="border border-gray-200 p-3">{enrollment.courses?.code}</td>
                              <td className="border border-gray-200 p-3">{enrollment.courses?.name}</td>
                              <td className="border border-gray-200 p-3 text-center">{enrollment.courses?.credits}</td>
                              <td className="border border-gray-200 p-3 text-center">
                                <Badge variant="outline">{enrollment.grade}</Badge>
                              </td>
                              <td className="border border-gray-200 p-3 text-center">
                                {enrollment.grade === "AA"
                                  ? "4.00"
                                  : enrollment.grade === "BA"
                                    ? "3.50"
                                    : enrollment.grade === "BB"
                                      ? "3.00"
                                      : enrollment.grade === "CB"
                                        ? "2.50"
                                        : enrollment.grade === "CC"
                                          ? "2.00"
                                          : "-"}
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Calculator Tab - Aynı kalıyor */}
          <TabsContent value="calculator" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Not Hesaplama Aracı</CardTitle>
                  <CardDescription>Vize, final ve diğer notlarınızı hesaplayın</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="midterm">Vize Notu (0-100)</Label>
                      <Input
                        id="midterm"
                        type="number"
                        min="0"
                        max="100"
                        value={gradeCalculator.midterm}
                        onChange={(e) => setGradeCalculator((prev) => ({ ...prev, midterm: e.target.value }))}
                        placeholder="Vize notunuz"
                      />
                    </div>
                    <div>
                      <Label htmlFor="midtermWeight">Vize Ağırlığı (%)</Label>
                      <Input
                        id="midtermWeight"
                        type="number"
                        min="0"
                        max="100"
                        value={gradeCalculator.midtermWeight}
                        onChange={(e) =>
                          setGradeCalculator((prev) => ({
                            ...prev,
                            midtermWeight: Number.parseInt(e.target.value) || 0,
                          }))
                        }
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="final">Final Notu (0-100)</Label>
                      <Input
                        id="final"
                        type="number"
                        min="0"
                        max="100"
                        value={gradeCalculator.final}
                        onChange={(e) => setGradeCalculator((prev) => ({ ...prev, final: e.target.value }))}
                        placeholder="Final notunuz"
                      />
                    </div>
                    <div>
                      <Label htmlFor="finalWeight">Final Ağırlığı (%)</Label>
                      <Input
                        id="finalWeight"
                        type="number"
                        min="0"
                        max="100"
                        value={gradeCalculator.finalWeight}
                        onChange={(e) =>
                          setGradeCalculator((prev) => ({ ...prev, finalWeight: Number.parseInt(e.target.value) || 0 }))
                        }
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="homework">Ödev Notu (0-100)</Label>
                      <Input
                        id="homework"
                        type="number"
                        min="0"
                        max="100"
                        value={gradeCalculator.homework}
                        onChange={(e) => setGradeCalculator((prev) => ({ ...prev, homework: e.target.value }))}
                        placeholder="Ödev notunuz (opsiyonel)"
                      />
                    </div>
                    <div>
                      <Label htmlFor="homeworkWeight">Ödev Ağırlığı (%)</Label>
                      <Input
                        id="homeworkWeight"
                        type="number"
                        min="0"
                        max="100"
                        value={gradeCalculator.homeworkWeight}
                        onChange={(e) =>
                          setGradeCalculator((prev) => ({
                            ...prev,
                            homeworkWeight: Number.parseInt(e.target.value) || 0,
                          }))
                        }
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="quiz">Quiz Notu (0-100)</Label>
                      <Input
                        id="quiz"
                        type="number"
                        min="0"
                        max="100"
                        value={gradeCalculator.quiz}
                        onChange={(e) => setGradeCalculator((prev) => ({ ...prev, quiz: e.target.value }))}
                        placeholder="Quiz notunuz (opsiyonel)"
                      />
                    </div>
                    <div>
                      <Label htmlFor="quizWeight">Quiz Ağırlığı (%)</Label>
                      <Input
                        id="quizWeight"
                        type="number"
                        min="0"
                        max="100"
                        value={gradeCalculator.quizWeight}
                        onChange={(e) =>
                          setGradeCalculator((prev) => ({
                            ...prev,
                            quizWeight: Number.parseInt(e.target.value) || 0,
                          }))
                        }
                      />
                    </div>
                  </div>

                  <div className="pt-4">
                    <div className="flex justify-between text-sm mb-2">
                      <span>Toplam Ağırlık:</span>
                      <span
                        className={
                          gradeCalculator.midtermWeight +
                            gradeCalculator.finalWeight +
                            gradeCalculator.homeworkWeight +
                            gradeCalculator.quizWeight ===
                          100
                            ? "text-green-600"
                            : "text-red-600"
                        }
                      >
                        {gradeCalculator.midtermWeight +
                          gradeCalculator.finalWeight +
                          gradeCalculator.homeworkWeight +
                          gradeCalculator.quizWeight}
                        %
                      </span>
                    </div>
                    <Button onClick={calculateGrade} className="w-full">
                      Notu Hesapla
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Hesaplama Sonucu</CardTitle>
                  <CardDescription>Genel notunuz ve harf karşılığı</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {calculatedGrade ? (
                    <>
                      <div className="text-center space-y-4">
                        <div className="p-6 bg-blue-50 rounded-lg">
                          <h3 className="text-lg font-medium text-blue-900 mb-2">Genel Notunuz</h3>
                          <p className="text-4xl font-bold text-blue-600">{calculatedGrade}</p>
                          <p className="text-sm text-blue-700">100 üzerinden</p>
                        </div>

                        <div className="p-6 bg-green-50 rounded-lg">
                          <h3 className="text-lg font-medium text-green-900 mb-2">Harf Notu</h3>
                          <p className="text-3xl font-bold text-green-600">{letterGrade}</p>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <h4 className="font-medium">Not Detayları:</h4>
                        <div className="space-y-2 text-sm">
                          {gradeCalculator.midterm && (
                            <div className="flex justify-between">
                              <span>Vize ({gradeCalculator.midtermWeight}%):</span>
                              <span>
                                {gradeCalculator.midterm} →{" "}
                                {(
                                  (Number.parseFloat(gradeCalculator.midterm) * gradeCalculator.midtermWeight) /
                                  100
                                ).toFixed(2)}
                              </span>
                            </div>
                          )}
                          {gradeCalculator.final && (
                            <div className="flex justify-between">
                              <span>Final ({gradeCalculator.finalWeight}%):</span>
                              <span>
                                {gradeCalculator.final} →{" "}
                                {(
                                  (Number.parseFloat(gradeCalculator.final) * gradeCalculator.finalWeight) /
                                  100
                                ).toFixed(2)}
                              </span>
                            </div>
                          )}
                          {gradeCalculator.homework && gradeCalculator.homeworkWeight > 0 && (
                            <div className="flex justify-between">
                              <span>Ödev ({gradeCalculator.homeworkWeight}%):</span>
                              <span>
                                {gradeCalculator.homework} →{" "}
                                {(
                                  (Number.parseFloat(gradeCalculator.homework) * gradeCalculator.homeworkWeight) /
                                  100
                                ).toFixed(2)}
                              </span>
                            </div>
                          )}
                          {gradeCalculator.quiz && gradeCalculator.quizWeight > 0 && (
                            <div className="flex justify-between">
                              <span>Quiz ({gradeCalculator.quizWeight}%):</span>
                              <span>
                                {((Number.parseFloat(gradeCalculator.quiz) * gradeCalculator.quizWeight) / 100).toFixed(
                                  2,
                                )}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                    </>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <Calculator className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>Notlarınızı girin ve hesapla butonuna tıklayın</p>
                    </div>
                  )}

                  <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                    <h4 className="font-medium mb-2">Harf Notu Skalası:</h4>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>AA: 90-100</div>
                      <div>BA: 85-89</div>
                      <div>BB: 80-84</div>
                      <div>CB: 75-79</div>
                      <div>CC: 70-74</div>
                      <div>DC: 65-69</div>
                      <div>DD: 60-64</div>
                      <div>FD: 50-59</div>
                      <div>FF: 0-49</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Messages Tab */}
          <TabsContent value="messages" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[600px]">
              {/* Chat List */}
              <Card className="lg:col-span-1">
                <CardHeader>
                  <CardTitle>Mesajlar</CardTitle>
                  <CardDescription>📁 JSON dosyasından mesajlar</CardDescription>
                </CardHeader>
                <CardContent className="p-0">
                  <ScrollArea className="h-[500px]">
                    <div className="space-y-2 p-4">
                      {messages.map((chat) => (
                        <div
                          key={chat.id}
                          className={`p-3 rounded-lg cursor-pointer transition-colors ${
                            selectedChat?.id === chat.id ? "bg-blue-50 border-blue-200 border" : "hover:bg-gray-50"
                          }`}
                          onClick={() => setSelectedChat(chat)}
                        >
                          <div className="flex items-start space-x-3">
                            <Avatar className="h-10 w-10">
                              <AvatarFallback className="text-xs">
                                {chat.sender_name
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("")}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between">
                                <p className="text-sm font-medium truncate">{chat.sender_name}</p>
                                <div className="flex items-center gap-2">
                                  <span className="text-xs text-gray-500">
                                    {new Date(chat.created_at).toLocaleTimeString("tr-TR", {
                                      hour: "2-digit",
                                      minute: "2-digit",
                                    })}
                                  </span>
                                  {!chat.is_read && (
                                    <Badge className="h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                                      1
                                    </Badge>
                                  )}
                                </div>
                              </div>
                              <p className="text-xs text-gray-500">Öğretim Üyesi</p>
                              <p className="text-sm text-gray-600 truncate mt-1">{chat.content}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              {/* Chat Window */}
              <Card className="lg:col-span-2">
                {selectedChat ? (
                  <>
                    <CardHeader className="border-b">
                      <div className="flex items-center space-x-3">
                        <Avatar>
                          <AvatarFallback>
                            {selectedChat.sender_name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <CardTitle className="text-lg">{selectedChat.sender_name}</CardTitle>
                          <CardDescription>📁 JSON Mesajlaşma</CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="p-0">
                      <ScrollArea className="h-[400px] p-4">
                        <div className="space-y-4">
                          {messages
                            .filter((m) => m.sender_name === selectedChat.sender_name)
                            .map((message) => (
                              <div
                                key={message.id}
                                className={`flex ${message.sender_name === student?.name ? "justify-end" : "justify-start"}`}
                              >
                                <div
                                  className={`max-w-[70%] p-3 rounded-lg ${
                                    message.sender_name === student?.name
                                      ? "bg-blue-500 text-white"
                                      : "bg-gray-100 text-gray-900"
                                  }`}
                                >
                                  <p className="text-sm">{message.content}</p>
                                  <p
                                    className={`text-xs mt-1 ${message.sender_name === student?.name ? "text-blue-100" : "text-gray-500"}`}
                                  >
                                    {new Date(message.created_at).toLocaleTimeString("tr-TR", {
                                      hour: "2-digit",
                                      minute: "2-digit",
                                    })}
                                  </p>
                                </div>
                              </div>
                            ))}
                        </div>
                      </ScrollArea>
                      <div className="border-t p-4">
                        <div className="flex space-x-2">
                          <Textarea
                            placeholder="Mesajınızı yazın... (JSON dosyasına kaydedilecek)"
                            value={newMessage}
                            onChange={(e) => setNewMessage(e.target.value)}
                            className="flex-1 min-h-[40px] max-h-[120px]"
                            onKeyPress={(e) => {
                              if (e.key === "Enter" && !e.shiftKey) {
                                e.preventDefault()
                                handleSendMessage()
                              }
                            }}
                          />
                          <Button onClick={handleSendMessage} size="icon">
                            <Send className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </>
                ) : (
                  <CardContent className="flex items-center justify-center h-full">
                    <div className="text-center text-gray-500">
                      <MessageCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>Bir sohbet seçin</p>
                    </div>
                  </CardContent>
                )}
              </Card>
            </div>
          </TabsContent>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Kişisel Bilgiler</CardTitle>
                  <CardDescription>📁 JSON dosyasından profil bilgileri</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-4 mb-6">
                    <Avatar className="h-20 w-20">
                      <AvatarImage src="/placeholder.svg?height=80&width=80" />
                      <AvatarFallback className="text-lg">
                        {student?.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("") ||
                          currentUser.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <Button variant="outline">Fotoğraf Değiştir</Button>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Ad Soyad</Label>
                      <Input id="name" value={student?.name || currentUser.name} readOnly className="bg-gray-50" />
                    </div>
                    <div>
                      <Label htmlFor="studentId">Öğrenci No</Label>
                      <Input
                        id="studentId"
                        value={student?.student_id || currentUser.student_id || ""}
                        readOnly
                        className="bg-gray-50"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="department">Bölüm</Label>
                    <Input
                      id="department"
                      value={student?.department || "Bilgisayar Mühendisliği"}
                      readOnly
                      className="bg-gray-50"
                    />
                  </div>

                  <div>
                    <Label htmlFor="year">Sınıf</Label>
                    <Input id="year" value={student?.year || "3. Sınıf"} readOnly className="bg-gray-50" />
                  </div>

                  <div>
                    <Label htmlFor="email">E-posta</Label>
                    <Input
                      id="email"
                      value={editableProfile.email}
                      onChange={(e) => setEditableProfile((prev) => ({ ...prev, email: e.target.value }))}
                    />
                  </div>

                  <div>
                    <Label htmlFor="phone">Telefon</Label>
                    <Input
                      id="phone"
                      value={editableProfile.phone}
                      onChange={(e) => setEditableProfile((prev) => ({ ...prev, phone: e.target.value }))}
                    />
                  </div>

                  <Button className="w-full" onClick={handleUpdateProfile}>
                    📁 JSON Dosyasında Güncelle
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Şifre Değiştir</CardTitle>
                  <CardDescription>📁 JSON dosyasında şifre güncelleme</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="currentPassword">Mevcut Şifre</Label>
                    <Input
                      id="currentPassword"
                      type="password"
                      value={passwordData.currentPassword}
                      onChange={(e) => setPasswordData((prev) => ({ ...prev, currentPassword: e.target.value }))}
                    />
                  </div>

                  <div>
                    <Label htmlFor="newPassword">Yeni Şifre</Label>
                    <Input
                      id="newPassword"
                      type="password"
                      value={passwordData.newPassword}
                      onChange={(e) => setPasswordData((prev) => ({ ...prev, newPassword: e.target.value }))}
                    />
                  </div>

                  <div>
                    <Label htmlFor="confirmPassword">Yeni Şifre (Tekrar)</Label>
                    <Input
                      id="confirmPassword"
                      type="password"
                      value={passwordData.confirmPassword}
                      onChange={(e) => setPasswordData((prev) => ({ ...prev, confirmPassword: e.target.value }))}
                    />
                  </div>

                  <Button className="w-full" onClick={handleChangePassword}>
                    📁 JSON'da Şifreyi Değiştir
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Schedule Tab */}
          <TabsContent value="schedule" className="space-y-6">
            <ScheduleEditor />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
