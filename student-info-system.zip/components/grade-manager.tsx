"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Plus, Edit, Save, X } from "lucide-react"
import { addGrade } from "@/lib/simple-database"

interface GradeManagerProps {
  courses: any[]
  student: any
  onGradeUpdate: () => void
}

export function GradeManager({ courses, student, onGradeUpdate }: GradeManagerProps) {
  const [editingCourse, setEditingCourse] = useState<string | null>(null)
  const [newGrade, setNewGrade] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleSaveGrade = async (courseId: string) => {
    if (!newGrade || !student) {
      alert("⚠️ Lütfen bir not seçin!")
      return
    }

    setIsLoading(true)
    try {
      console.log("📁 JSON dosyasına not ekleniyor:", { studentId: student.student_id, courseId, grade: newGrade })

      const result = addGrade(student.student_id, courseId, newGrade)

      if (result) {
        setEditingCourse(null)
        setNewGrade("")
        onGradeUpdate()
        alert("✅ Not JSON dosyasına başarıyla eklendi!")
      } else {
        alert("❌ Not eklenirken hata oluştu!")
      }
    } catch (error) {
      console.error("Error saving grade:", error)
      alert("❌ Not eklenirken hata oluştu!")
    } finally {
      setIsLoading(false)
    }
  }

  const gradeOptions = ["AA", "BA", "BB", "CB", "CC", "DC", "DD", "FD", "FF"]

  return (
    <div className="space-y-4">
      <div className="p-3 bg-green-50 border border-green-200 rounded-lg mb-4">
        <p className="text-sm text-green-700">
          📁 <strong>JSON Veritabanı:</strong> Notlar yerel dosyaya kaydediliyor
        </p>
      </div>

      {courses.map((enrollment) => (
        <div key={enrollment.id} className="flex items-center justify-between p-4 border rounded-lg">
          <div className="flex-1">
            <h3 className="font-medium">{enrollment.courses?.name}</h3>
            <p className="text-sm text-muted-foreground">
              {enrollment.courses?.code} • {enrollment.courses?.credits} Kredi
            </p>
            <p className="text-sm text-muted-foreground">{enrollment.courses?.instructor}</p>
          </div>
          <div className="flex items-center gap-4">
            <Badge
              variant={
                enrollment.status === "completed"
                  ? "default"
                  : enrollment.status === "enrolled"
                    ? "secondary"
                    : "outline"
              }
            >
              {enrollment.status === "completed"
                ? "Tamamlandı"
                : enrollment.status === "enrolled"
                  ? "Devam Ediyor"
                  : "Kayıtlı"}
            </Badge>

            {editingCourse === enrollment.course_id ? (
              <div className="flex items-center gap-2">
                <Select value={newGrade} onValueChange={setNewGrade}>
                  <SelectTrigger className="w-20">
                    <SelectValue placeholder="Not" />
                  </SelectTrigger>
                  <SelectContent>
                    {gradeOptions.map((grade) => (
                      <SelectItem key={grade} value={grade}>
                        {grade}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button
                  size="sm"
                  onClick={() => handleSaveGrade(enrollment.course_id)}
                  disabled={isLoading || !newGrade}
                >
                  <Save className="h-4 w-4" />
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    setEditingCourse(null)
                    setNewGrade("")
                  }}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                {enrollment.grade ? (
                  <Badge variant="outline">{enrollment.grade}</Badge>
                ) : (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setEditingCourse(enrollment.course_id)
                      setNewGrade("")
                    }}
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Not Ekle
                  </Button>
                )}
                {enrollment.grade && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setEditingCourse(enrollment.course_id)
                      setNewGrade(enrollment.grade)
                    }}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                )}
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  )
}
