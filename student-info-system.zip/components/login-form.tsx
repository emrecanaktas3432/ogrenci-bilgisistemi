"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, GraduationCap, Eye, EyeOff } from "lucide-react"
import { authenticateUser, setCurrentUser, type LoginCredentials } from "@/lib/auth"

interface LoginFormProps {
  onLoginSuccess: () => void
}

export function LoginForm({ onLoginSuccess }: LoginFormProps) {
  const [credentials, setCredentials] = useState<LoginCredentials>({
    username: "",
    password: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [showPassword, setShowPassword] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    try {
      const user = await authenticateUser(credentials)

      if (user) {
        setCurrentUser(user)
        onLoginSuccess()
      } else {
        setError("Kullanıcı adı veya şifre hatalı!")
      }
    } catch (err) {
      setError("Giriş yapılırken bir hata oluştu!")
    } finally {
      setIsLoading(false)
    }
  }

  const fillDemoCredentials = (userType: "student" | "teacher" | "admin") => {
    switch (userType) {
      case "student":
        setCredentials({ username: "2021000001", password: "123456" })
        break
      case "teacher":
        setCredentials({ username: "mehmet.yilmaz", password: "teacher123" })
        break
      case "admin":
        setCredentials({ username: "admin", password: "admin123" })
        break
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="bg-blue-600 p-3 rounded-full">
              <GraduationCap className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-gray-900">Öğrenci Bilgi Sistemi</h1>
          <p className="text-gray-600 mt-2">Hesabınıza giriş yapın</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Giriş Yap</CardTitle>
            <CardDescription>Öğrenci numaranız veya kullanıcı adınız ile giriş yapın</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username">Kullanıcı Adı / Öğrenci No</Label>
                <Input
                  id="username"
                  type="text"
                  value={credentials.username}
                  onChange={(e) => setCredentials((prev) => ({ ...prev, username: e.target.value }))}
                  placeholder="Örn: 2021000001"
                  required
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Şifre</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={credentials.password}
                    onChange={(e) => setCredentials((prev) => ({ ...prev, password: e.target.value }))}
                    placeholder="Şifrenizi girin"
                    required
                    disabled={isLoading}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                    disabled={isLoading}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>

              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Giriş yapılıyor...
                  </>
                ) : (
                  "Giriş Yap"
                )}
              </Button>
            </form>

            <div className="mt-6">
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-background px-2 text-muted-foreground">Demo Hesaplar</span>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-2 mt-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => fillDemoCredentials("student")}
                  disabled={isLoading}
                  className="text-xs"
                >
                  👨‍🎓 Öğrenci Girişi (2021000001)
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => fillDemoCredentials("teacher")}
                  disabled={isLoading}
                  className="text-xs"
                >
                  👨‍🏫 Öğretmen Girişi (mehmet.yilmaz)
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => fillDemoCredentials("admin")}
                  disabled={isLoading}
                  className="text-xs"
                >
                  👨‍💼 Admin Girişi (admin)
                </Button>
              </div>
            </div>

            <div className="mt-6 text-center">
              <Button variant="link" className="text-sm text-muted-foreground">
                Şifremi Unuttum
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="mt-6 text-center text-sm text-gray-500">
          <p>Demo hesap bilgileri:</p>
          <p>Öğrenci: 2021000001 / 123456</p>
          <p>Öğretmen: mehmet.yilmaz / teacher123</p>
          <p>Admin: admin / admin123</p>
        </div>
      </div>
    </div>
  )
}
