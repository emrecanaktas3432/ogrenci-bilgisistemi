"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Edit, Trash2 } from "lucide-react"

interface ScheduleItem {
  id: string
  day: string
  time: string
  course: string
  room: string
  color: string
}

export function ScheduleEditor() {
  const [schedule, setSchedule] = useState<ScheduleItem[]>([
    { id: "1", day: "Pazartesi", time: "09:00-10:00", course: "Veri Yapıları", room: "A-101", color: "bg-blue-100" },
    { id: "2", day: "Çarşamba", time: "09:00-10:00", course: "Web Programlama", room: "B-205", color: "bg-green-100" },
    { id: "3", day: "Cuma", time: "09:00-10:00", course: "Yazılım Müh.", room: "C-301", color: "bg-purple-100" },
    { id: "4", day: "Salı", time: "10:00-11:00", course: "Veritabanı", room: "A-102", color: "bg-yellow-100" },
    { id: "5", day: "Perşembe", time: "10:00-11:00", course: "Mobil Uygulama", room: "B-201", color: "bg-red-100" },
    { id: "6", day: "Çarşamba", time: "11:00-12:00", course: "Veri Yapıları Lab", room: "Lab-1", color: "bg-blue-100" },
  ])

  const [editingItem, setEditingItem] = useState<ScheduleItem | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const days = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma"]
  const timeSlots = [
    "08:00-09:00",
    "09:00-10:00",
    "10:00-11:00",
    "11:00-12:00",
    "12:00-13:00",
    "13:00-14:00",
    "14:00-15:00",
    "15:00-16:00",
    "16:00-17:00",
  ]
  const colors = [
    { name: "Mavi", value: "bg-blue-100" },
    { name: "Yeşil", value: "bg-green-100" },
    { name: "Sarı", value: "bg-yellow-100" },
    { name: "Kırmızı", value: "bg-red-100" },
    { name: "Mor", value: "bg-purple-100" },
    { name: "Pembe", value: "bg-pink-100" },
  ]

  const handleSave = () => {
    if (!editingItem) return

    if (editingItem.id === "new") {
      const newItem = { ...editingItem, id: Date.now().toString() }
      setSchedule([...schedule, newItem])
    } else {
      setSchedule(schedule.map((item) => (item.id === editingItem.id ? editingItem : item)))
    }

    setEditingItem(null)
    setIsDialogOpen(false)
  }

  const handleDelete = (id: string) => {
    if (confirm("Bu dersi silmek istediğinizden emin misiniz?")) {
      setSchedule(schedule.filter((item) => item.id !== id))
    }
  }

  const handleAddNew = () => {
    setEditingItem({
      id: "new",
      day: "Pazartesi",
      time: "09:00-10:00",
      course: "",
      room: "",
      color: "bg-blue-100",
    })
    setIsDialogOpen(true)
  }

  const getScheduleForTimeSlot = (day: string, time: string) => {
    return schedule.find((item) => item.day === day && item.time === time)
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Haftalık Ders Programı</CardTitle>
            <CardDescription>Ders programınızı düzenleyin</CardDescription>
          </div>
          <Button onClick={handleAddNew}>Ders Ekle</Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse border border-gray-200">
            <thead>
              <tr className="bg-gray-50">
                <th className="border border-gray-200 p-3">Saat</th>
                {days.map((day) => (
                  <th key={day} className="border border-gray-200 p-3">
                    {day}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {timeSlots.map((time) => (
                <tr key={time}>
                  <td className="border border-gray-200 p-3 font-medium">{time}</td>
                  {days.map((day) => {
                    const item = getScheduleForTimeSlot(day, time)
                    return (
                      <td key={`${day}-${time}`} className="border border-gray-200 p-3">
                        {item ? (
                          <div className={`${item.color} p-2 rounded text-sm relative group`}>
                            <div className="font-medium">{item.course}</div>
                            <div className="text-xs">{item.room}</div>
                            <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              <div className="flex gap-1">
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-6 w-6 p-0"
                                  onClick={() => {
                                    setEditingItem(item)
                                    setIsDialogOpen(true)
                                  }}
                                >
                                  <Edit className="h-3 w-3" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-6 w-6 p-0 text-red-600"
                                  onClick={() => handleDelete(item.id)}
                                >
                                  <Trash2 className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        ) : null}
                      </td>
                    )
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingItem?.id === "new" ? "Yeni Ders Ekle" : "Ders Düzenle"}</DialogTitle>
              <DialogDescription>Ders bilgilerini girin</DialogDescription>
            </DialogHeader>
            {editingItem && (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="course">Ders Adı</Label>
                  <Input
                    id="course"
                    value={editingItem.course}
                    onChange={(e) => setEditingItem({ ...editingItem, course: e.target.value })}
                    placeholder="Ders adını girin"
                  />
                </div>
                <div>
                  <Label htmlFor="room">Sınıf</Label>
                  <Input
                    id="room"
                    value={editingItem.room}
                    onChange={(e) => setEditingItem({ ...editingItem, room: e.target.value })}
                    placeholder="Sınıf adını girin"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="day">Gün</Label>
                    <Select
                      value={editingItem.day}
                      onValueChange={(value) => setEditingItem({ ...editingItem, day: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {days.map((day) => (
                          <SelectItem key={day} value={day}>
                            {day}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="time">Saat</Label>
                    <Select
                      value={editingItem.time}
                      onValueChange={(value) => setEditingItem({ ...editingItem, time: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {timeSlots.map((time) => (
                          <SelectItem key={time} value={time}>
                            {time}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label htmlFor="color">Renk</Label>
                  <Select
                    value={editingItem.color}
                    onValueChange={(value) => setEditingItem({ ...editingItem, color: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {colors.map((color) => (
                        <SelectItem key={color.value} value={color.value}>
                          <div className="flex items-center gap-2">
                            <div className={`w-4 h-4 rounded ${color.value}`}></div>
                            {color.name}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                    İptal
                  </Button>
                  <Button onClick={handleSave}>Kaydet</Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  )
}
