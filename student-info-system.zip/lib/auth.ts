// Authentication utilities
export interface LoginCredentials {
  username: string
  password: string
}

export interface User {
  id: string
  username: string
  name: string
  role: "student" | "teacher" | "admin"
  student_id?: string
}

// Demo users for testing
const demoUsers = [
  {
    id: "1",
    username: "2021000001",
    password: "123456",
    name: "Örnek Öğrenci",
    role: "student" as const,
    student_id: "2021000001",
  },
  {
    id: "2",
    username: "ayse.demir",
    password: "123456",
    name: "Ayşe Demir",
    role: "student" as const,
    student_id: "2021000002",
  },
  {
    id: "3",
    username: "admin",
    password: "admin123",
    name: "Sistem Yöneticisi",
    role: "admin" as const,
  },
  {
    id: "4",
    username: "mehmet.yilmaz",
    password: "teacher123",
    name: "Prof. Dr. Mehmet Yılmaz",
    role: "teacher" as const,
  },
]

// Demo kullanıcıları dışa aktar
export { demoUsers }

import { authenticateUser as jsonAuth } from "@/lib/simple-database"

export async function authenticateUser(credentials: LoginCredentials): Promise<User | null> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  const user = jsonAuth(credentials.username, credentials.password)
  return user
}

export function getCurrentUser(): User | null {
  if (typeof window === "undefined") return null

  const userData = localStorage.getItem("currentUser")
  return userData ? JSON.parse(userData) : null
}

export function setCurrentUser(user: User | null) {
  if (typeof window === "undefined") return

  if (user) {
    localStorage.setItem("currentUser", JSON.stringify(user))
  } else {
    localStorage.removeItem("currentUser")
  }
}

export function logout() {
  setCurrentUser(null)
  window.location.reload()
}

// Kullanıcı bilgilerini güncelleme fonksiyonu
export async function updateUserInfo(userId: string, updates: any) {
  const user = demoUsers.find((u) => u.id === userId)
  if (user) {
    Object.assign(user, updates)
    return user
  }
  return null
}
