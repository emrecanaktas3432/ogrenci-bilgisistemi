import { supabase } from "./supabase"
import type { Student } from "./supabase"

// Demo data for fallback
const demoStudent = {
  id: "demo-id",
  student_id: "2021000001",
  name: "Örnek Öğrenci",
  email: "ornek.ogrenci@demo.edu.tr",
  phone: "+90 5XX XXX XX XX",
  department: "Bilgisayar Mühendisliği",
  year: "3. Sınıf",
  gpa: 3.45,
  created_at: new Date().toISOString(),
}

const demoCourses = [
  {
    id: "1",
    student_id: "demo-id",
    course_id: "1",
    grade: "AA",
    status: "completed",
    created_at: new Date().toISOString(),
    courses: {
      id: "1",
      code: "BM301",
      name: "Veri Yapıları ve Algoritmalar",
      credits: 4,
      instructor: "Prof. Dr. Mehmet Yılmaz",
    },
  },
  {
    id: "2",
    student_id: "demo-id",
    course_id: "2",
    grade: "BA",
    status: "completed",
    created_at: new Date().toISOString(),
    courses: {
      id: "2",
      code: "BM302",
      name: "Veritabanı Yönetim Sistemleri",
      credits: 3,
      instructor: "Doç. Dr. Fatma Özkan",
    },
  },
  {
    id: "3",
    student_id: "demo-id",
    course_id: "3",
    grade: null,
    status: "enrolled",
    created_at: new Date().toISOString(),
    courses: {
      id: "3",
      code: "BM303",
      name: "Web Programlama",
      credits: 3,
      instructor: "Dr. Öğr. Üyesi Ahmet Kara",
    },
  },
  {
    id: "4",
    student_id: "demo-id",
    course_id: "4",
    grade: null,
    status: "enrolled",
    created_at: new Date().toISOString(),
    courses: {
      id: "4",
      code: "BM304",
      name: "Yazılım Mühendisliği",
      credits: 4,
      instructor: "Prof. Dr. Zeynep Aydın",
    },
  },
  {
    id: "5",
    student_id: "demo-id",
    course_id: "5",
    grade: null,
    status: "enrolled",
    created_at: new Date().toISOString(),
    courses: {
      id: "5",
      code: "BM305",
      name: "Mobil Uygulama Geliştirme",
      credits: 3,
      instructor: "Dr. Öğr. Üyesi Can Demir",
    },
  },
]

const demoMessages = [
  {
    id: "1",
    sender_id: "teacher-1",
    receiver_id: "demo-id",
    content: "Proje teslim tarihi hakkında bilgi almak istiyorum.",
    is_read: false,
    created_at: new Date().toISOString(),
    sender: "Prof. Dr. Mehmet Yılmaz",
  },
  {
    id: "2",
    sender_id: "student-1",
    receiver_id: "demo-id",
    content: "Yarınki sınav için çalışalım mı?",
    is_read: false,
    created_at: new Date().toISOString(),
    sender: "Ayşe Demir",
  },
]

const demoAnnouncements = [
  {
    id: "1",
    title: "Final Sınavı Tarihleri Açıklandı",
    content: "Final sınavları 15-25 Ocak tarihleri arasında yapılacaktır.",
    type: "Sınav",
    created_at: new Date().toISOString(),
  },
  {
    id: "2",
    title: "Yeni Dönem Ders Kayıtları Başladı",
    content: "Bahar dönemi ders kayıtları 10 Ocak tarihinde başlamıştır.",
    type: "Kayıt",
    created_at: new Date().toISOString(),
  },
]

const demoWeather = {
  id: "1",
  city: "Ankara",
  temperature: 22,
  condition: "sunny",
  description: "Güneşli",
  humidity: 65,
  wind_speed: 12,
  updated_at: new Date().toISOString(),
}

// Test Supabase connection
export async function testConnection() {
  try {
    const { data, error } = await supabase.from("students").select("count").limit(1)
    if (error) {
      console.log("⚠️ Supabase tables not found, using demo data")
      return false
    }
    console.log("✅ Supabase connection successful!")
    return true
  } catch (error) {
    console.log("⚠️ Supabase connection failed, using demo data")
    return false
  }
}

// Student functions
export async function getStudent(studentId: string): Promise<Student | null> {
  try {
    const { data, error } = await supabase.from("students").select("*").eq("student_id", studentId).single()

    if (error) {
      console.log("📊 Using demo student data")
      return demoStudent
    }

    console.log("✅ Student data loaded from Supabase")
    return data
  } catch (error) {
    console.log("📊 Using demo student data")
    return demoStudent
  }
}

export async function updateStudent(studentId: string, updates: Partial<Student>) {
  try {
    const { data, error } = await supabase
      .from("students")
      .update(updates)
      .eq("student_id", studentId)
      .select()
      .single()

    if (error) {
      console.log("📊 Demo mode: Simulating student update")
      return { ...demoStudent, ...updates }
    }

    return data
  } catch (error) {
    console.log("📊 Demo mode: Simulating student update")
    return { ...demoStudent, ...updates }
  }
}

// Course functions
export async function getStudentCourses(studentId: string) {
  try {
    const { data, error } = await supabase
      .from("enrollments")
      .select(`
        *,
        courses (
          id,
          code,
          name,
          credits,
          instructor
        )
      `)
      .eq("student_id", studentId)

    if (error) {
      console.log("📊 Using demo courses data")
      return demoCourses
    }

    console.log("✅ Courses data loaded from Supabase")
    return data
  } catch (error) {
    console.log("📊 Using demo courses data")
    return demoCourses
  }
}

export async function updateGrade(enrollmentId: string, grade: string) {
  try {
    const { data, error } = await supabase
      .from("enrollments")
      .update({ grade, status: "completed" })
      .eq("id", enrollmentId)
      .select()
      .single()

    if (error) {
      console.error("Error updating grade:", error)
      return null
    }

    return data
  } catch (error) {
    console.error("Error updating grade:", error)
    return null
  }
}

// Message functions
export async function getMessages(userId: string) {
  try {
    const { data, error } = await supabase
      .from("messages")
      .select(`
        *,
        sender:students!messages_sender_id_fkey(name),
        receiver:students!messages_receiver_id_fkey(name)
      `)
      .or(`sender_id.eq.${userId},receiver_id.eq.${userId}`)
      .order("created_at", { ascending: false })

    if (error) {
      console.log("📊 Using demo messages data")
      return [...demoMessages]
    }

    console.log("✅ Messages data loaded from Supabase")
    return data
  } catch (error) {
    console.log("📊 Using demo messages data")
    return [...demoMessages]
  }
}

export async function sendMessage(senderId: string, receiverId: string, content: string) {
  try {
    const { data, error } = await supabase
      .from("messages")
      .insert({
        sender_id: senderId,
        receiver_id: receiverId,
        content,
      })
      .select()
      .single()

    if (error) {
      console.log("📊 Demo mode: Simulating message send")
      const newMessage = {
        id: Date.now().toString(),
        sender_id: senderId,
        receiver_id: receiverId,
        content,
        is_read: false,
        created_at: new Date().toISOString(),
        sender: "Örnek Öğrenci",
      }
      demoMessages.unshift(newMessage)
      return newMessage
    }

    console.log("✅ Message sent via Supabase")
    return data
  } catch (error) {
    console.log("📊 Demo mode: Simulating message send")
    const newMessage = {
      id: Date.now().toString(),
      sender_id: senderId,
      receiver_id: receiverId,
      content,
      is_read: false,
      created_at: new Date().toISOString(),
      sender: "Örnek Öğrenci",
    }
    demoMessages.unshift(newMessage)
    return newMessage
  }
}

// Announcement functions
export async function getAnnouncements() {
  try {
    const { data, error } = await supabase
      .from("announcements")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(10)

    if (error) {
      console.log("📊 Using demo announcements data")
      return demoAnnouncements
    }

    console.log("✅ Announcements data loaded from Supabase")
    return data
  } catch (error) {
    console.log("📊 Using demo announcements data")
    return demoAnnouncements
  }
}

// Weather functions
export async function getWeather(city = "Ankara") {
  try {
    const { data, error } = await supabase.from("weather").select("*").eq("city", city).single()

    if (error) {
      console.log("📊 Using demo weather data")
      return demoWeather
    }

    console.log("✅ Weather data loaded from Supabase")
    return data
  } catch (error) {
    console.log("📊 Using demo weather data")
    return demoWeather
  }
}

export async function updateWeather(city: string, weatherData: any) {
  try {
    const { data, error } = await supabase
      .from("weather")
      .upsert({
        city,
        ...weatherData,
        updated_at: new Date().toISOString(),
      })
      .select()
      .single()

    if (error) {
      console.log("📊 Demo mode: Simulating weather update")
      return { ...demoWeather, ...weatherData }
    }

    return data
  } catch (error) {
    console.log("📊 Demo mode: Simulating weather update")
    return { ...demoWeather, ...weatherData }
  }
}

// Yeni not ekleme fonksiyonu
export async function addGrade(studentId: string, courseId: string, grade: string) {
  try {
    const { data, error } = await supabase
      .from("enrollments")
      .update({ grade, status: "completed" })
      .eq("student_id", studentId)
      .eq("course_id", courseId)
      .select()
      .single()

    if (error) {
      console.log("📊 Demo mode: Simulating grade addition")
      const courseIndex = demoCourses.findIndex((c) => c.course_id === courseId && c.student_id === studentId)
      if (courseIndex !== -1) {
        demoCourses[courseIndex].grade = grade
        demoCourses[courseIndex].status = "completed"
        return demoCourses[courseIndex]
      }
      return null
    }

    console.log("✅ Grade added via Supabase")
    return data
  } catch (error) {
    console.log("📊 Demo mode: Simulating grade addition")
    const courseIndex = demoCourses.findIndex((c) => c.course_id === courseId && c.student_id === studentId)
    if (courseIndex !== -1) {
      demoCourses[courseIndex].grade = grade
      demoCourses[courseIndex].status = "completed"
      return demoCourses[courseIndex]
    }
    return null
  }
}

// Şifre değiştirme fonksiyonu
export async function changePassword(userId: string, currentPassword: string, newPassword: string) {
  // Bu fonksiyon Supabase Auth ile entegre edilebilir
  console.log("📊 Demo mode: Simulating password change")
  return { success: true, message: "Şifre başarıyla değiştirildi!" }
}
