import fs from "fs"
import path from "path"

// JSON dosyasını oku
function readDatabase() {
  try {
    const filePath = path.join(process.cwd(), "data", "database.json")
    const fileContent = fs.readFileSync(filePath, "utf8")
    return JSON.parse(fileContent)
  } catch (error) {
    console.error("Veritabanı dosyası okunamadı:", error)
    return null
  }
}

// JSON dosyasına yaz
function writeDatabase(data: any) {
  try {
    const filePath = path.join(process.cwd(), "data", "database.json")
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2))
    return true
  } catch (error) {
    console.error("Veritabanı dosyasına yazılamadı:", error)
    return false
  }
}

// Öğrenci getir
export function getStudent(studentId: string) {
  const db = readDatabase()
  if (!db) return null

  return db.students.find((student: any) => student.student_id === studentId)
}

// Öğrenci güncelle
export function updateStudent(studentId: string, updates: any) {
  const db = readDatabase()
  if (!db) return null

  const studentIndex = db.students.findIndex((student: any) => student.student_id === studentId)
  if (studentIndex === -1) return null

  db.students[studentIndex] = { ...db.students[studentIndex], ...updates }
  writeDatabase(db)

  return db.students[studentIndex]
}

// Öğrenci derslerini getir
export function getStudentCourses(studentId: string) {
  const db = readDatabase()
  if (!db) return []

  const student = db.students.find((s: any) => s.student_id === studentId)
  if (!student) return []

  const enrollments = db.enrollments.filter((e: any) => e.student_id === student.id)

  return enrollments.map((enrollment: any) => {
    const course = db.courses.find((c: any) => c.id === enrollment.course_id)
    return {
      ...enrollment,
      courses: course,
    }
  })
}

// Not ekle/güncelle
export function addGrade(studentId: string, courseId: string, grade: string) {
  const db = readDatabase()
  if (!db) return null

  const student = db.students.find((s: any) => s.student_id === studentId)
  if (!student) return null

  const enrollmentIndex = db.enrollments.findIndex((e: any) => e.student_id === student.id && e.course_id === courseId)

  if (enrollmentIndex === -1) return null

  db.enrollments[enrollmentIndex].grade = grade
  db.enrollments[enrollmentIndex].status = "completed"

  writeDatabase(db)
  return db.enrollments[enrollmentIndex]
}

// Mesajları getir
export function getMessages(userId: string) {
  const db = readDatabase()
  if (!db) return []

  return db.messages.filter((msg: any) => msg.sender_id === userId || msg.receiver_id === userId)
}

// Mesaj gönder
export function sendMessage(senderId: string, receiverId: string, content: string, senderName: string) {
  const db = readDatabase()
  if (!db) return null

  const newMessage = {
    id: (db.messages.length + 1).toString(),
    sender_id: senderId,
    receiver_id: receiverId,
    sender_name: senderName,
    content,
    is_read: false,
    created_at: new Date().toISOString(),
  }

  db.messages.push(newMessage)
  writeDatabase(db)

  return newMessage
}

// Duyuruları getir
export function getAnnouncements() {
  const db = readDatabase()
  if (!db) return []

  return db.announcements.sort((a: any, b: any) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
}

// Hava durumunu getir
export function getWeather() {
  const db = readDatabase()
  if (!db) return null

  return db.weather
}

// Kullanıcı doğrula
export function authenticateUser(username: string, password: string) {
  const db = readDatabase()
  if (!db) return null

  // Öğrenci kontrolü
  const student = db.students.find((s: any) => s.student_id === username && s.password === password)
  if (student) {
    return {
      id: student.id,
      username: student.student_id,
      name: student.name,
      role: "student",
      student_id: student.student_id,
    }
  }

  // Öğretmen kontrolü
  const teacher = db.teachers.find((t: any) => t.username === username && t.password === password)
  if (teacher) {
    return {
      id: teacher.id,
      username: teacher.username,
      name: teacher.name,
      role: "teacher",
    }
  }

  // Admin kontrolü
  const admin = db.admins.find((a: any) => a.username === username && a.password === password)
  if (admin) {
    return {
      id: admin.id,
      username: admin.username,
      name: admin.name,
      role: "admin",
    }
  }

  return null
}

// Şifre değiştir
export function changePassword(userId: string, currentPassword: string, newPassword: string) {
  const db = readDatabase()
  if (!db) return { success: false, message: "Veritabanı hatası!" }

  const student = db.students.find((s: any) => s.id === userId)
  if (!student) return { success: false, message: "Kullanıcı bulunamadı!" }

  if (student.password !== currentPassword) {
    return { success: false, message: "Mevcut şifre hatalı!" }
  }

  student.password = newPassword
  writeDatabase(db)

  return { success: true, message: "Şifre başarıyla değiştirildi!" }
}
