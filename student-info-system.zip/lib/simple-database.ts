// Basit veritabanı wrapper - hem JSON hem Supabase destekler
import * as jsonDb from "./json-database"

// JSON veritabanını kullan
export const getStudent = jsonDb.getStudent
export const updateStudent = jsonDb.updateStudent
export const getStudentCourses = jsonDb.getStudentCourses
export const addGrade = jsonDb.addGrade
export const getMessages = jsonDb.getMessages
export const sendMessage = jsonDb.sendMessage
export const getAnnouncements = jsonDb.getAnnouncements
export const getWeather = jsonDb.getWeather
export const authenticateUser = jsonDb.authenticateUser
export const changePassword = jsonDb.changePassword

console.log("📁 JSON Veritabanı aktif!")
