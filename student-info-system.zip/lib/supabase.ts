import { createClient } from "@supabase/supabase-js"

// Supabase configuration
const supabaseUrl = "https://jnvwbykvxbbglijcvruc.supabase.co"
const supabaseAnonKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpudndieWt2eGJiZ2xpamN2cnVjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTAyMzkwMzIsImV4cCI6MjA2NTgxNTAzMn0.HjVqm47_dhU069Wbcn75UE2q_eKH8LrAVXvHGi1R7yg"

// Create Supabase client
export const supabase = createClient(supabaseUrl, supabaseAnonKey)

console.log("✅ Supabase client initialized successfully!")

// Database types
export interface Student {
  id: string
  student_id: string
  name: string
  email: string
  phone: string
  department: string
  year: string
  gpa: number
  created_at: string
}

export interface Course {
  id: string
  code: string
  name: string
  credits: number
  instructor: string
  semester: string
  created_at: string
}

export interface Enrollment {
  id: string
  student_id: string
  course_id: string
  grade: string | null
  status: "enrolled" | "completed" | "dropped"
  created_at: string
}

export interface Message {
  id: string
  sender_id: string
  receiver_id: string
  content: string
  is_read: boolean
  created_at: string
}

export interface Announcement {
  id: string
  title: string
  content: string
  type: string
  created_at: string
}
