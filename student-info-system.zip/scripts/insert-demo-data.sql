-- Insert sample students
INSERT INTO students (student_id, name, email, phone, department, year, gpa) VALUES
('2021000001', 'Örnek Öğrenci', 'ornek.ogrenci@demo.edu.tr', '+90 5XX XXX XX XX', 'Bilgisayar Mühendisliği', '3. Sınıf', 3.45),
('2021000002', 'Ayşe Demir', 'ayse.demir@demo.edu.tr', '+90 5XX XXX XX XX', 'Bilgisayar Mühendisliği', '3. Sınıf', 3.20),
('2021000003', 'Ali Kaya', 'ali.kaya@demo.edu.tr', '+90 5XX XXX XX XX', 'Bilgisayar Mühendisliği', '3. Sınıf', 3.80);

-- Insert sample courses
INSERT INTO courses (code, name, credits, instructor, semester) VALUES
('BM301', 'Veri Yapıları ve Algoritmalar', 4, 'Prof. Dr. Mehmet Yılmaz', '2024-1'),
('BM302', 'Veritabanı Yönetim Sistemleri', 3, 'Doç. Dr. Fatma Özkan', '2024-1'),
('BM303', 'Web Programlama', 3, 'Dr. Öğr. Üyesi Ahmet Kara', '2024-1'),
('BM304', 'Yazılım Mühendisliği', 4, 'Prof. Dr. Zeynep Aydın', '2024-1'),
('BM305', 'Mobil Uygulama Geliştirme', 3, 'Dr. Öğr. Üyesi Can Demir', '2024-1');

-- Insert sample enrollments (using subqueries to get the correct IDs)
INSERT INTO enrollments (student_id, course_id, grade, status) VALUES
((SELECT id FROM students WHERE student_id = '2021000001'), (SELECT id FROM courses WHERE code = 'BM301'), 'AA', 'completed'),
((SELECT id FROM students WHERE student_id = '2021000001'), (SELECT id FROM courses WHERE code = 'BM302'), 'BA', 'completed'),
((SELECT id FROM students WHERE student_id = '2021000001'), (SELECT id FROM courses WHERE code = 'BM303'), NULL, 'enrolled'),
((SELECT id FROM students WHERE student_id = '2021000001'), (SELECT id FROM courses WHERE code = 'BM304'), NULL, 'enrolled'),
((SELECT id FROM students WHERE student_id = '2021000001'), (SELECT id FROM courses WHERE code = 'BM305'), NULL, 'enrolled');

-- Insert enrollments for other students
INSERT INTO enrollments (student_id, course_id, grade, status) VALUES
((SELECT id FROM students WHERE student_id = '2021000002'), (SELECT id FROM courses WHERE code = 'BM301'), 'BA', 'completed'),
((SELECT id FROM students WHERE student_id = '2021000002'), (SELECT id FROM courses WHERE code = 'BM302'), 'BB', 'completed'),
((SELECT id FROM students WHERE student_id = '2021000002'), (SELECT id FROM courses WHERE code = 'BM303'), NULL, 'enrolled'),
((SELECT id FROM students WHERE student_id = '2021000003'), (SELECT id FROM courses WHERE code = 'BM301'), 'AA', 'completed'),
((SELECT id FROM students WHERE student_id = '2021000003'), (SELECT id FROM courses WHERE code = 'BM302'), 'AA', 'completed');

-- Insert sample messages
INSERT INTO messages (sender_id, receiver_id, content, is_read) VALUES
((SELECT id FROM students WHERE student_id = '2021000002'), (SELECT id FROM students WHERE student_id = '2021000001'), 'Yarınki sınav için çalışalım mı?', false),
((SELECT id FROM students WHERE student_id = '2021000003'), (SELECT id FROM students WHERE student_id = '2021000001'), 'Proje hakkında konuşabilir miyiz?', false),
((SELECT id FROM students WHERE student_id = '2021000001'), (SELECT id FROM students WHERE student_id = '2021000002'), 'Tabii ki! Saat kaçta buluşalım?', true);

-- Insert sample announcements
INSERT INTO announcements (title, content, type) VALUES
('Final Sınavı Tarihleri Açıklandı', 'Final sınavları 15-25 Ocak tarihleri arasında yapılacaktır. Tüm öğrencilerin sınav programını kontrol etmesi gerekmektedir.', 'Sınav'),
('Yeni Dönem Ders Kayıtları Başladı', 'Bahar dönemi ders kayıtları 10 Ocak tarihinde başlamıştır. Kayıt için öğrenci bilgi sistemini kullanınız.', 'Kayıt'),
('Burs Başvuruları İçin Son Tarih', 'Başarı bursu başvuruları için son tarih 8 Ocak 2024. Gerekli belgelerinizi hazırlayınız.', 'Burs'),
('Kütüphane Çalışma Saatleri Güncellendi', 'Sınav döneminde kütüphane 24 saat açık olacaktır. Sessiz çalışma alanları rezerve edilebilir.', 'Duyuru'),
('Mezuniyet Töreni Tarihi Belirlendi', '2024 Bahar dönemi mezuniyet töreni 15 Haziran tarihinde yapılacaktır.', 'Etkinlik');

-- Insert sample weather data
INSERT INTO weather (city, temperature, condition, description, humidity, wind_speed) VALUES
('Ankara', 22, 'sunny', 'Güneşli', 65, 12);
