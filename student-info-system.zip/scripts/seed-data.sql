-- Insert sample students
INSERT INTO students (student_id, name, email, phone, department, year, gpa) VALUES
('2021000001', 'Örnek Öğrenci', 'ornek.ogrenci@demo.edu.tr', '+90 5XX XXX XX XX', 'Bilgisayar Mühendisliği', '3. Sınıf', 3.45),
('2021000002', 'Ayşe Demir', 'ayse.demir@demo.edu.tr', '+90 5XX XXX XX XX', 'Bilgisayar Mühendisliği', '3. Sınıf', 3.20),
('2021000003', 'Ali Kaya', 'ali.kaya@demo.edu.tr', '+90 5XX XXX XX XX', 'Bilgisayar Mühendisliği', '3. Sınıf', 3.80);

-- Insert sample courses
INSERT INTO courses (code, name, credits, instructor, semester) VALUES
('BM301', 'Veri Yapıları ve Algoritmalar', 4, 'Prof. Dr. Mehmet Yılmaz', '2024-1'),
('BM302', 'Veritabanı Yönetim Sistemleri', 3, 'Doç. Dr. Fatma Özkan', '2024-1'),
('BM303', 'Web Programlama', 3, 'Dr. Öğr. Üyesi Ahmet Kara', '2024-1'),
('BM304', 'Yazılım Mühendisliği', 4, 'Prof. Dr. Zeynep Aydın', '2024-1'),
('BM305', 'Mobil Uygulama Geliştirme', 3, 'Dr. Öğr. Üyesi Can Demir', '2024-1');

-- Insert sample enrollments
INSERT INTO enrollments (student_id, course_id, grade, status) VALUES
((SELECT id FROM students WHERE student_id = '2021000001'), (SELECT id FROM courses WHERE code = 'BM301'), 'AA', 'completed'),
((SELECT id FROM students WHERE student_id = '2021000001'), (SELECT id FROM courses WHERE code = 'BM302'), 'BA', 'completed'),
((SELECT id FROM students WHERE student_id = '2021000001'), (SELECT id FROM courses WHERE code = 'BM303'), NULL, 'enrolled'),
((SELECT id FROM students WHERE student_id = '2021000001'), (SELECT id FROM courses WHERE code = 'BM304'), NULL, 'enrolled'),
((SELECT id FROM students WHERE student_id = '2021000001'), (SELECT id FROM courses WHERE code = 'BM305'), NULL, 'enrolled');

-- Insert sample announcements
INSERT INTO announcements (title, content, type) VALUES
('Final Sınavı Tarihleri Açıklandı', 'Final sınavları 15-25 Ocak tarihleri arasında yapılacaktır.', 'Sınav'),
('Yeni Dönem Ders Kayıtları Başladı', 'Bahar dönemi ders kayıtları 10 Ocak tarihinde başlamıştır.', 'Kayıt'),
('Burs Başvuruları İçin Son Tarih', 'Başarı bursu başvuruları için son tarih 8 Ocak 2024.', 'Burs');

-- Insert sample weather data
INSERT INTO weather (city, temperature, condition, description, humidity, wind_speed) VALUES
('Ankara', 22, 'sunny', 'Güneşli', 65, 12);
